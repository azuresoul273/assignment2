class company
{
    constructor(compname,country,owner)
    {
        this.compname=compname;
        this.country=country;
        this.owner=owner;
    }
    getCarname()
    {
        return this.compname;
    }
}

class car extends company
{
    constructor(carname,compname,country,owner,established,group)
    {
        super(compname,country,owner);
        this.established=established;
        this.carname=carname;
        this.group=group;

    }
    getModel()
    {
        return this.carname;
    }
   
    
}
 let Car1=new car('Audi RS 7 Sportback','AUDI AG','Germany','Markus Duesmann','16 July 1909','Volkswagen');
 console.log(Car1.getModel());